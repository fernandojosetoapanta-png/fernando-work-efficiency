# Fernando Work Efficiency

Two compact Codex skills focused on reducing unnecessary context, repeated reads, oversized tool output, and redundant work without sacrificing correctness.

## Included skills
- `work-efficiency`
- `context-compression-lite`

## Install with Codex skill-installer

Use the official skill installer with:

```bash
scripts/install-skill-from-github.py --repo fernandojosetoapanta-png/fernando-work-efficiency --path skills/work-efficiency skills/context-compression-lite
```

Or ask Codex to install both skills from this repository.

These skills do not bypass or increase plan limits; they only aim to reduce avoidable context/tool overhead.
