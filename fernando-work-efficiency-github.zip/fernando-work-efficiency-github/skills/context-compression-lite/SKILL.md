---
name: context-compression-lite
description: Use only in long-running, multi-step, or tool-heavy Work/Codex tasks where earlier decisions, files, results, and next steps are becoming difficult to carry efficiently. Create or update a compact durable task state instead of repeating the whole history. Do not activate for short conversations.
---

# Context Compression Lite

Optimize for tokens per completed task, not maximum compression.

## When to use

Use this skill when one or more are true:
- many tool calls or file edits have accumulated;
- several versions of the same artifact exist;
- the task spans multiple stages and prior decisions must be preserved;
- rereading earlier material is starting to repeat work;
- a handoff or continuation would otherwise require reconstructing the session.

## Compact state format

Maintain a concise state with only:
1. Goal and current deliverable.
2. Locked user constraints.
3. Decisions already made and why they matter.
4. Exact files/artifacts currently in use.
5. Verified facts/results that should not be recomputed.
6. Current status.
7. Remaining steps.
8. Open blockers or uncertainties.

## Update rule

- Update by delta: change only fields affected by new work.
- Drop superseded intermediate attempts unless needed to explain a constraint or rollback path.
- Keep exact identifiers, filenames, versions, and critical numeric values when they are needed for continuation.
- Do not compress away citations, safety constraints, unresolved errors, or user-approved design decisions.
- If a durable scratchpad/file is available, store the compact state there and retrieve it only when needed.

## Reuse rule

Before repeating a search, read, test, or generation step, check whether the compact state already contains a still-valid result. Recompute only when freshness, changed inputs, or uncertainty justifies it.
