# File work reference

Use these tactics only when editing or analyzing files.

- Locate before reading: filename/metadata -> search/find -> targeted range -> full file only if necessary.
- Prefer incremental edits over regeneration when the existing file is the intended base.
- Keep a simple change set: target, requested modification, preserved elements, validation performed.
- For structured formats, modify the structure with an appropriate library/tool instead of flattening to text.
- For visual documents, inspect rendered output only when layout or appearance matters.
- Avoid reopening the same unchanged source after every edit; cache the relevant facts or coordinates in the working state.
- If a tool returns a next-page/range cursor, continue only when the needed content is not yet covered.
