# Research reference

- Translate the user goal into 1-3 concrete unresolved questions.
- Prefer primary/official sources for specifications, policies, documentation, and current product behavior.
- Use community sources mainly for experience, edge cases, and sentiment.
- Search in batches when supported, but do not broaden scope unless initial evidence is insufficient.
- Open only the strongest candidates and extract the minimum evidence needed.
- Stop searching once independent evidence adequately supports the requested conclusion.
- For time-sensitive topics, verify freshness explicitly.
- Never trade away source quality merely to reduce calls.
