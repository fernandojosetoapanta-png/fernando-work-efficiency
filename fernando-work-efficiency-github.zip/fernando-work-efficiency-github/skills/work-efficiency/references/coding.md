# Coding reference

- Start with repository status, relevant paths, and precise symbol search.
- Prefer `git diff --stat` / `--name-only` before full diffs.
- Use `rg`/AST search before broad file reads.
- Suppress unhelpful build/test noise when a quiet or machine-readable mode exists.
- Run focused unit or target tests first; expand only if the change can affect wider behavior.
- Do not re-run unchanged expensive steps without a reason.
- Use a small script for deterministic bulk transforms; validate a sample and then the full result.
- Preserve user code style and surrounding architecture unless the task asks for refactoring.
