---
name: work-efficiency
description: Use for multi-step Work/Codex tasks involving files, code, research, tool calls, or artifact editing when efficiency matters. Reduce unnecessary context, repeated reads, redundant searches, oversized tool output, and full regenerations while preserving correctness, citations, validation, and user intent. Do not activate for trivial one-step chat questions.
---

# Work Efficiency

Optimize for useful work completed per unit of context, not for the shortest possible answer.

## Core rules

1. Start from the narrowest sufficient source. Search/select first; read the smallest relevant range or file portion next.
2. Filter tool output at the source. Prefer targeted search, structured extraction, summaries, `rg`, `find`, `jq`, `git --stat`, `--name-only`, or equivalent over dumping large raw outputs.
3. Reuse valid prior results. Do not re-read or re-fetch unchanged files, pages, repositories, or data unless a later step depends on fresh verification.
4. Edit in place. When an existing artifact already satisfies most requirements, patch only the necessary parts instead of rebuilding it from scratch.
5. Batch compatible operations when the tool supports it. Avoid serial calls that could safely be grouped.
6. Prefer deterministic transforms for repetitive mechanical work when a short script or direct edit is more reliable and cheaper than repeated model generation.
7. Keep temporary analysis and terminal output concise. Save verbose diagnostics to a file only when they may be needed later.
8. Stop when the requested result is complete and verified. Do not add optional searches, checks, or rewrites that do not materially improve confidence or quality.
9. Escalate depth only when uncertainty affects the answer. A simple task should not inherit the workflow of a complex one.
10. Preserve safety and quality. Never skip a required citation, validation, test, visual inspection, or user constraint merely to save context.

## File and artifact workflow

- Identify the exact target before reading broadly.
- Prefer metadata/search/find to locate the relevant section.
- Read only the surrounding section needed for the edit.
- Preserve formatting, structure, formulas, and unchanged content.
- After editing, verify the changed region first; perform a full validation only when the file format or change can create global breakage.
- If the user asks to modify version N, use version N as the base unless they explicitly request a rebuild.

For detailed file guidance, read `references/file-work.md` only when the task involves files or artifacts.

## Coding workflow

- Inspect the smallest set of files that controls the behavior.
- Prefer symbol/term search over opening large files from top to bottom.
- Make focused patches.
- Run the narrowest meaningful test first; broaden only if needed.
- Summarize large logs before bringing them into context.

For detailed coding guidance, read `references/coding.md` only for coding or repository work.

## Research workflow

- Search only when outside information is required.
- Use a few targeted queries and authoritative sources before broad exploration.
- Avoid duplicate searches that return the same evidence.
- Open only sources likely to answer the unresolved point.
- Keep source-derived claims distinct from inference.

For detailed research guidance, read `references/research.md` only for research-heavy tasks.

## Long sessions

If the task has become long, fragmented, or tool-heavy, use the separate `context-compression-lite` skill instead of repeatedly carrying every intermediate detail forward.

## Quality gate

Before finishing, check only the dimensions relevant to the task:
- requested output exists;
- key constraints were preserved;
- changed portions work;
- factual claims that need sources are sourced;
- no unresolved blocker was silently ignored.

Do not perform redundant validation once these conditions are satisfied.
